package com.example.hospitalproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalprojectApplication.class, args);
	}

}
